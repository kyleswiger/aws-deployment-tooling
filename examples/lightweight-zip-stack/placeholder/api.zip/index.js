exports.handler = async () => ({ statusCode: 200, body: "placeholder — replace via deploy.sh" });
